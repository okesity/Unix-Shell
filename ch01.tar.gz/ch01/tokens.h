#ifndef TOKENS_H
#define TOKENS_H

#include "list.h"
list* tokenize(char* text);

#endif